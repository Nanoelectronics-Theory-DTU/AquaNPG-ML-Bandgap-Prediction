import os
import numpy as np
import pandas as pd

# Parameters
cutoff = 5.0  # Å for OH distances
rdf_cutoff = 16  # Å for RDF
rdf_bins = np.arange(3, rdf_cutoff, 1)  # 3-15 Å, 1 Å width

# Device periodicity in x and y (Å)
Lx = 32.786
Ly = 8.69346

results = []

# === Helper functions ===
def read_xyz(file_path):
    """Read atomic coordinates from xyz file."""
    with open(file_path) as f:
        lines = f.readlines()
    atoms = []
    for line in lines[2:]:
        parts = line.split()
        if len(parts) >= 4:
            atoms.append((parts[0], np.array(list(map(float, parts[1:4])))))
    return atoms

def pbc_distance(vec1, vec2):
    """Compute minimum image distance with PBC."""
    delta = vec1 - vec2
    delta[0] -= Lx * np.round(delta[0] / Lx)
    delta[1] -= Ly * np.round(delta[1] / Ly)
    return np.linalg.norm(delta)

def compute_dipole_centered(coords, charges):
    """Compute molecular dipole relative to center of geometry."""
    center = np.mean(coords, axis=0)
    coords_rel = coords - center
    dip_eA = np.sum(charges[:, None] * coords_rel, axis=0)
    return dip_eA * 4.80320427  # Debye

def angle_with_z(vector):
    """Compute angle (degrees) between vector and z-axis."""
    z_axis = np.array([0, 0, 1])
    cos_theta = np.dot(vector, z_axis) / (np.linalg.norm(vector) + 1e-12)
    cos_theta = np.clip(cos_theta, -1, 1)
    return np.degrees(np.arccos(cos_theta))

# Get only numeric folders and sort numerically
folders = [f for f in os.listdir(".") if os.path.isdir(f) and f.isdigit()]
folders = sorted(folders, key=lambda x: int(x))  # Numeric sort

for folder in folders:
    xyz_files = [f for f in os.listdir(folder) if f.endswith(".xyz")]
    if not xyz_files:
        continue

    xyz_path = os.path.join(folder, xyz_files[0])
    atoms = read_xyz(xyz_path)
    if len(atoms) <= 98:
        print(f"⚠️ Skipping {folder}: not enough atoms")
        continue

    # Water atom indices (assume single water at 100,101,102)
    O_idx, H1_idx, H2_idx = 100, 101, 102
    O_pos = atoms[O_idx][1]
    H1_pos = atoms[H1_idx][1]
    H2_pos = atoms[H2_idx][1]
    water_positions = np.array([O_pos, H1_pos, H2_pos])

    # Center of geometry
    center_geom = np.mean(water_positions, axis=0)

    # Distance from water plane (Z)

    # Minimum O···H distance (to other Hs, excluding water Hs)
    OH_dists = [
        pbc_distance(O_pos, pos)
        for i, (sym, pos) in enumerate(atoms)
        if sym == "H" and i not in [H1_idx, H2_idx] and pbc_distance(O_pos, pos) <= cutoff
    ]
    min_OH = np.min(OH_dists) if OH_dists else np.nan

    # Dipole
    water_charges = np.array([-2, 1, 1])
    dipole_vec = compute_dipole_centered(water_positions, water_charges)
    dipole_mag = np.linalg.norm(dipole_vec)
    dipole_angle = angle_with_z(dipole_vec)

    # Distances to carbons
    carbon_positions = [pos for sym, pos in atoms if sym == "C"]
    dists_to_carbons = [pbc_distance(center_geom, c) for c in carbon_positions]
    min_C_dist = np.min(dists_to_carbons) if dists_to_carbons else np.nan
    max_C_dist = np.max(dists_to_carbons) if dists_to_carbons else np.nan
    std_C_dist = np.std(dists_to_carbons) if dists_to_carbons else np.nan


    # Save results
    result = {
        "Folder": int(folder),  # Actual numeric folder number
        "Water_COG_x": center_geom[0],
        "Water_COG_y": center_geom[1],
        "Water_COG_z": center_geom[2],
        "Min_OH_distance": min_OH,
        "Dipole_X(D)": dipole_vec[0],
        "Dipole_Y(D)": dipole_vec[1],
        "Dipole_Z(D)": dipole_vec[2],
        "Dipole_Magnitude(D)": dipole_mag,
        "Dipole_angle_deg": dipole_angle,
        "Dist_to_C_min": min_C_dist,
        "Dist_to_C_max": max_C_dist,
        "Dist_to_C_std": std_C_dist
    }
results.append(result)

# Save to Excel
df = pd.DataFrame(results)
df.to_excel("full_water_features.xlsx", index=False)
print("✅ Features saved to 'full_water_features.xlsx'")

