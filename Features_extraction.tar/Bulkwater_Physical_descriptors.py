import os
import re
import numpy as np
import pandas as pd

# ============================================================
# USER SETTINGS
# ============================================================

boundary_atom_1 = 55
boundary_atom_2 = 58

surface_normal = np.array([0.0, 0.0, 1.0])

OH_contact_cutoff = 2.5
NH_contact_cutoff = 2.5
OO_contact_cutoff = 3.5

output_file = "final_selected_features_with_ribbon_density.xlsx"

# Water density region along z (Angstrom).
# Set to None to use the full simulation-cell height.
# Example: (3.0, 9.0)
water_z_range = None

# Optional simulation-cell dimensions in Angstrom.
# Use only if XYZ does not contain Lattice information.
# Example: (25.0, 20.0, 30.0)
manual_cell_lengths = None


# ============================================================
# READ XYZ AND SIMULATION CELL
# ============================================================

def read_xyz(file_path):
    with open(file_path) as f:
        lines = f.readlines()

    atoms = []

    for line in lines[2:]:
        parts = line.split()

        if len(parts) >= 4:
            try:
                atoms.append((
                    parts[0],
                    np.array(list(map(float, parts[1:4])))
                ))
            except ValueError:
                continue

    cell = None

    if len(lines) > 1:
        match = re.search(
            r'Lattice="([^"]+)"',
            lines[1]
        )

        if match:
            values = np.fromstring(match.group(1), sep=" ")

            if len(values) == 9:
                cell = values.reshape(3, 3)

    if cell is None and manual_cell_lengths is not None:
        cell = np.diag(manual_cell_lengths)

    return atoms, cell


# ============================================================
# ORIGINAL DIPOLE FUNCTIONS
# ============================================================

def compute_dipole_centered(coords, charges):
    center = np.mean(coords, axis=0)
    coords_rel = coords - center

    dip_eA = np.sum(
        charges[:, None] * coords_rel,
        axis=0
    )

    return dip_eA * 4.80320427


def angle_with_normal(vec, normal):
    vnorm = np.linalg.norm(vec)
    nnorm = np.linalg.norm(normal)

    if vnorm == 0 or nnorm == 0:
        return np.nan

    cosang = np.dot(vec, normal) / (vnorm * nnorm)
    cosang = np.clip(cosang, -1.0, 1.0)

    return np.degrees(np.arccos(cosang))


# ============================================================
# DETECT WATER MOLECULES
# ============================================================

def detect_waters(atoms):
    waters = []
    water_charges = np.array([-2, 1, 1])

    for i in range(len(atoms) - 2):

        if (
            atoms[i][0] == "O"
            and atoms[i+1][0] == "H"
            and atoms[i+2][0] == "H"
        ):

            coords = np.array([
                atoms[i][1],
                atoms[i+1][1],
                atoms[i+2][1]
            ])

            cog = np.mean(coords, axis=0)

            dip_vec = compute_dipole_centered(
                coords,
                water_charges
            )

            waters.append({
                "O_index": i,
                "H_indices": [i+1, i+2],
                "O_coord": atoms[i][1],
                "H_coords": [
                    atoms[i+1][1],
                    atoms[i+2][1]
                ],
                "COG": cog,
                "dip_vec": dip_vec,
                "dip_mag": np.linalg.norm(dip_vec),
                "dip_angle": angle_with_normal(
                    dip_vec,
                    surface_normal
                )
            })

    return waters


# ============================================================
# ORIGINAL WATER-WATER O-H FEATURES
# ============================================================

def water_water_OH_features(waters):
    distances = []

    for i, wi in enumerate(waters):
        for j, wj in enumerate(waters):

            if i == j:
                continue

            for H_coord in wj["H_coords"]:
                distances.append(
                    np.linalg.norm(
                        wi["O_coord"] - H_coord
                    )
                )

    if not distances:
        return np.nan, np.nan, 0

    distances = np.array(distances)

    return (
        np.min(distances),
        np.mean(distances),
        np.sum(distances <= OH_contact_cutoff)
    )


# ============================================================
# ORIGINAL SUBSTRATE N-H FEATURES
# ============================================================

def substrate_NH_features(atoms, waters):
    N_coords = np.array([
        pos for sym, pos in atoms if sym == "N"
    ])

    if len(N_coords) == 0:
        return np.nan, np.nan, 0

    H_coords = []

    for w in waters:
        H_coords.extend(w["H_coords"])

    if not H_coords:
        return np.nan, np.nan, 0

    distances = []

    for N in N_coords:
        for H in H_coords:
            distances.append(
                np.linalg.norm(N - H)
            )

    distances = np.array(distances)

    return (
        np.min(distances),
        np.mean(distances),
        np.sum(distances <= NH_contact_cutoff)
    )


# ============================================================
# ORIGINAL TOTAL WATER-LAYER FEATURES
# ============================================================

def total_layer_features(waters, atoms):

    if len(waters) == 0:
        return {}

    cogs = np.array([w["COG"] for w in waters])
    dipoles = np.array([w["dip_vec"] for w in waters])
    dip_mags = np.array([w["dip_mag"] for w in waters])
    dip_angles = np.array([w["dip_angle"] for w in waters])

    total_dip = np.sum(dipoles, axis=0)

    min_OH, mean_OH, num_OH = water_water_OH_features(waters)
    min_NH, mean_NH, num_NH = substrate_NH_features(
        atoms, waters
    )

    return {
        "Water_COG_mean_x": np.mean(cogs[:, 0]),
        "Water_COG_mean_y": np.mean(cogs[:, 1]),
        "Water_COG_mean_z": np.mean(cogs[:, 2]),

        "Water_COG_std_x": np.std(cogs[:, 0]),
        "Water_COG_std_y": np.std(cogs[:, 1]),
        "Water_COG_std_z": np.std(cogs[:, 2]),

        "Total_Dipole_X": total_dip[0],
        "Total_Dipole_Y": total_dip[1],
        "Total_Dipole_Z": total_dip[2],
        "Total_Dipole_Mag": np.linalg.norm(total_dip),

        "Mean_Water_Dipole": np.mean(dip_mags),
        "Std_Water_Dipole": np.std(dip_mags),

        "Mean_Water_Dipole_Angle": np.nanmean(dip_angles),
        "Std_Water_Dipole_Angle": np.nanstd(dip_angles),

        "Min_OH_distance": min_OH,
        "Mean_OH_distance": mean_OH,
        "Num_OH_contacts": num_OH,

        "Min_NH_distance": min_NH,
        "Mean_NH_distance": mean_NH,
        "Num_NH_contacts": num_NH,
    }


# ============================================================
# ORIGINAL RIBBON DIPOLE FEATURES
# ============================================================

def ribbon_dipole_features(waters):

    if len(waters) == 0:
        return {
            "Total_Dipole_X": np.nan,
            "Total_Dipole_Y": np.nan,
            "Total_Dipole_Z": np.nan,
            "Total_Dipole_Mag": np.nan,
            "Mean_Water_Dipole": np.nan,
            "Std_Water_Dipole": np.nan,
        }

    dipoles = np.array([w["dip_vec"] for w in waters])
    dip_mags = np.array([w["dip_mag"] for w in waters])

    total_dip = np.sum(dipoles, axis=0)

    return {
        "Total_Dipole_X": total_dip[0],
        "Total_Dipole_Y": total_dip[1],
        "Total_Dipole_Z": total_dip[2],
        "Total_Dipole_Mag": np.linalg.norm(total_dip),
        "Mean_Water_Dipole": np.mean(dip_mags),
        "Std_Water_Dipole": np.std(dip_mags),
    }


def dipole_difference(central_feats, peripheral_feats):

    return {
        key: central_feats[key] - peripheral_feats[key]
        for key in central_feats
    }


# ============================================================
# NEW: O-O COORDINATION FEATURES
# ============================================================

def OO_features(waters):

    if len(waters) < 2:
        return np.nan, np.nan, 0

    O_coords = np.array([
        w["O_coord"] for w in waters
    ])

    diff = (
        O_coords[:, None, :]
        - O_coords[None, :, :]
    )

    distances = np.linalg.norm(diff, axis=2)

    np.fill_diagonal(distances, np.inf)

    minimum_OO = np.min(distances)

    contacts = distances <= OO_contact_cutoff

    coordination = np.mean(
        np.sum(contacts, axis=1)
    )

    # Unique water-water pairs
    num_contacts = np.sum(
        np.triu(contacts, k=1)
    )

    return minimum_OO, coordination, int(num_contacts)


# ============================================================
# NEW: LOCAL WATER DENSITY FEATURES
# ============================================================

def local_density_features(waters, volume_A3):

    count = len(waters)

    if volume_A3 is None or volume_A3 <= 0:
        number_density = np.nan
        mass_density = np.nan
    else:
        # molecules / nm^3
        number_density = count * 1000.0 / volume_A3

        # g / cm^3
        mass_density = (
            count * 18.01528
            / (6.02214076e23 * volume_A3 * 1e-24)
        )

    min_OO, coordination, num_OO = OO_features(waters)

    return {
        "Water_Count": count,
        "Volume_A3": volume_A3
            if volume_A3 is not None else np.nan,
        "Number_Density_nm3": number_density,
        "Mass_Density_g_cm3": mass_density,
        "Min_OO_Distance_A": min_OO,
        "Mean_OO_Coordination": coordination,
        "Num_OO_Contacts": num_OO,
    }


# ============================================================
# NEW: REGION VOLUME
# ============================================================

def region_volumes(cell, x_left, x_right):

    if cell is None:
        return None, None

    # This implementation requires an orthorhombic cell
    # aligned with Cartesian x, y, z.
    if not np.allclose(
        cell, np.diag(np.diag(cell)), atol=1e-6
    ):
        return None, None

    Lx, Ly, Lz = np.diag(cell)

    if min(Lx, Ly, Lz) <= 0:
        return None, None

    if water_z_range is None:
        height = Lz
    else:
        z_min, z_max = water_z_range
        height = z_max - z_min

        if height <= 0 or height > Lz:
            raise ValueError("Invalid water_z_range")

    central_width = x_right - x_left

    if central_width <= 0 or central_width > Lx:
        return None, None

    peripheral_width = Lx - central_width

    central_volume = central_width * Ly * height
    peripheral_volume = peripheral_width * Ly * height

    return central_volume, peripheral_volume


# ============================================================
# FIXED-CELL FALLBACK FOR XYZ FRAMES WITHOUT LATTICE
# ============================================================
# Read the lattice from all available XYZ frames before processing.
# A missing lattice can be replaced ONLY when the available frames
# establish a consistent, orthorhombic simulation cell.
# If every XYZ lacks Lattice, set manual_cell_lengths above.

cell_reference_tolerance = 0.01  # maximum relative deviation: 1%


def validated_cell_lengths(cell, source):
    if cell is None:
        return None
    if not np.allclose(cell, np.diag(np.diag(cell)), atol=1e-6):
        raise ValueError(f"{source}: non-orthorhombic cell is not supported")
    lengths = np.diag(cell).astype(float)
    if not np.all(np.isfinite(lengths)) or np.any(lengths <= 0):
        raise ValueError(f"{source}: invalid cell lengths {lengths}")
    return lengths


def find_reference_cell(frame_files):
    available = []
    for folder, xyz_path in frame_files:
        with open(xyz_path) as f:
            f.readline()
            comment = f.readline()
        match = re.search(r'Lattice="([^"]+)"', comment)
        if match:
            numbers = np.fromstring(match.group(1), sep=" ")
            if len(numbers) != 9:
                raise ValueError(f"{xyz_path}: malformed Lattice")
            available.append(validated_cell_lengths(numbers.reshape(3, 3), xyz_path))

    if available:
        lengths = np.array(available)
        reference = np.median(lengths, axis=0)
        relative_error = np.max(np.abs(lengths - reference) / reference)
        if relative_error > cell_reference_tolerance:
            raise ValueError(
                f"Inconsistent cell dimensions (max relative deviation "
                f"{relative_error:.3%}). Fixed-cell fallback is unsafe."
            )
        if manual_cell_lengths is not None:
            manual = validated_cell_lengths(np.diag(manual_cell_lengths), "manual_cell_lengths")
            if np.max(np.abs(manual - reference) / reference) > cell_reference_tolerance:
                raise ValueError("manual_cell_lengths disagree with XYZ lattice")
        print(f"Lattice found in {len(available)}/{len(frame_files)} frames")
        print(f"Reference cell (Angstrom): {reference}")
        return np.diag(reference)

    if manual_cell_lengths is not None:
        manual = validated_cell_lengths(np.diag(manual_cell_lengths), "manual_cell_lengths")
        print(f"Using user-specified cell (Angstrom): {manual}")
        return np.diag(manual)

    raise RuntimeError(
        "No XYZ frame contains a usable Lattice. Set manual_cell_lengths "
        "to the actual (Lx, Ly, Lz) from the AIMD input. "
        "Do not infer physical volume from atomic coordinates."
    )


# ============================================================
# MAIN LOOP
# ============================================================

results = []

folders = [
    f for f in os.listdir(".")
    if os.path.isdir(f) and f.isdigit()
]

folders = sorted(folders, key=lambda x: int(x))

# Resolve the input XYZ files and infer a validated reference cell once.
frame_files = []
for folder in folders:
    xyz_files = sorted(f for f in os.listdir(folder) if f.endswith(".xyz"))
    if xyz_files:
        frame_files.append((folder, os.path.join(folder, xyz_files[0])))

if not frame_files:
    raise RuntimeError("No XYZ files found in numeric folders")

reference_cell = find_reference_cell(frame_files)
missing_lattice_count = 0
folder_index = 1

for folder, xyz_path in frame_files:

    atoms, cell = read_xyz(xyz_path)
    if cell is None:
        cell = reference_cell.copy()
        missing_lattice_count += 1
    else:
        current_lengths = validated_cell_lengths(cell, xyz_path)
        reference_lengths = np.diag(reference_cell)
        if np.max(np.abs(current_lengths - reference_lengths) / reference_lengths) > cell_reference_tolerance:
            raise ValueError(f"{xyz_path}: cell differs from reference")

    if (
        boundary_atom_1 >= len(atoms)
        or boundary_atom_2 >= len(atoms)
    ):
        print(f"Skipping {folder}: invalid boundary atoms")
        continue

    waters = detect_waters(atoms)

    if not waters:
        print(f"Skipping {folder}: no water detected")
        continue

    x_b1 = atoms[boundary_atom_1][1][0]
    x_b2 = atoms[boundary_atom_2][1][0]

    x_left, x_right = sorted([x_b1, x_b2])

    central_ribbon = []
    peripheral_ribbon = []

    for w in waters:

        x = w["COG"][0]

        if water_z_range is not None:
            z = w["O_coord"][2]
            if not (
                water_z_range[0] <= z <= water_z_range[1]
            ):
                # Still included in original full-layer features,
                # but excluded from local-density analysis.
                continue

        if x_left <= x <= x_right:
            central_ribbon.append(w)
        else:
            peripheral_ribbon.append(w)

    # Original full-layer features
    total_feats = total_layer_features(waters, atoms)

    # Original ribbon dipole features must use all waters,
    # independently of the optional density z-range.
    central_all = [
        w for w in waters
        if x_left <= w["COG"][0] <= x_right
    ]

    peripheral_all = [
        w for w in waters
        if not (x_left <= w["COG"][0] <= x_right)
    ]

    central_dipole_feats = ribbon_dipole_features(
        central_all
    )

    peripheral_dipole_feats = ribbon_dipole_features(
        peripheral_all
    )

    diff_dipole_feats = dipole_difference(
        central_dipole_feats,
        peripheral_dipole_feats
    )

    central_volume, peripheral_volume = region_volumes(
        cell, x_left, x_right
    )
    if central_volume is None or peripheral_volume is None:
        raise ValueError(
            f"{xyz_path}: invalid ribbon boundaries or region volumes. "
            "Check boundary atom indices and cell orientation."
        )

    central_density = local_density_features(
        central_ribbon, central_volume
    )

    peripheral_density = local_density_features(
        peripheral_ribbon, peripheral_volume
    )

    row = {
        "Index": folder_index,
        "Folder": int(folder),
    }

    row.update(total_feats)

    for key, value in central_dipole_feats.items():
        row[f"Central_Ribbon_{key}"] = value

    for key, value in peripheral_dipole_feats.items():
        row[f"Peripheral_Ribbon_{key}"] = value

    for key, value in diff_dipole_feats.items():
        row[f"Ribbon_Difference_{key}"] = value

    for key, value in central_density.items():
        row[f"Central_{key}"] = value

    for key, value in peripheral_density.items():
        row[f"Peripheral_{key}"] = value

    for key in [
        "Water_Count",
        "Number_Density_nm3",
        "Mass_Density_g_cm3",
        "Mean_OO_Coordination",
    ]:
        row[f"Central_Minus_Peripheral_{key}"] = (
            central_density[key] - peripheral_density[key]
        )

    results.append(row)

    print(
        f"Frame {folder}: "
        f"central={len(central_ribbon)}, "
        f"peripheral={len(peripheral_ribbon)}"
    )

    folder_index += 1


# ============================================================
# SAVE FRAME FEATURES
# ============================================================

df = pd.DataFrame(results)

if df.empty:
    raise RuntimeError("No valid XYZ frames were processed.")


# ============================================================
# TEMPORAL DENSITY FLUCTUATIONS
# ============================================================

density_columns = [
    "Central_Water_Count",
    "Peripheral_Water_Count",
    "Central_Number_Density_nm3",
    "Peripheral_Number_Density_nm3",
    "Central_Mass_Density_g_cm3",
    "Peripheral_Mass_Density_g_cm3",
    "Central_Minus_Peripheral_Number_Density_nm3",
    "Central_Minus_Peripheral_Mass_Density_g_cm3",
]

summary_rows = []

for column in density_columns:

    values = df[column].dropna()

    mean = values.mean()
    std = values.std(ddof=1)

    summary_rows.append({
        "Descriptor": column,
        "Mean": mean,
        "Std": std,
        "Variance": values.var(ddof=1),
        "CV": std / mean
            if np.isfinite(mean) and mean != 0
            else np.nan,
        "Minimum": values.min(),
        "Maximum": values.max(),
        "N_Frames": len(values),
    })

summary = pd.DataFrame(summary_rows)


# ============================================================
# EXPORT EXCEL
# ============================================================

with pd.ExcelWriter(
    output_file,
    engine="openpyxl"
) as writer:

    df.to_excel(
        writer,
        sheet_name="Frame_Features",
        index=False
    )

    summary.to_excel(
        writer,
        sheet_name="Density_Fluctuations",
        index=False
    )

print()
print("==============================================")
print("Analysis completed")
print(f"Frames analyzed: {len(df)}")
print(f"Frames using reference lattice: {missing_lattice_count}")
print("Missing regional density values:",
      int(df[["Central_Number_Density_nm3", "Peripheral_Number_Density_nm3",
              "Central_Mass_Density_g_cm3", "Peripheral_Mass_Density_g_cm3"]].isna().sum().sum()))
print(f"Output: {output_file}")
print("==============================================")
