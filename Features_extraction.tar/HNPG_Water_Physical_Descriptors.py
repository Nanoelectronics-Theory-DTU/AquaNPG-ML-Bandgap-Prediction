import os
import numpy as np
import pandas as pd

cutoff = 5.0  # Å cutoff
results = []

def read_xyz(file_path):
    """Read atomic coordinates from xyz file."""
    with open(file_path) as f:
        lines = f.readlines()
    atoms = []
    for line in lines[2:]:
        parts = line.split()
        if len(parts) >= 4:
            atoms.append((parts[0], np.array(list(map(float, parts[1:4])))))
    return atoms

def compute_dipole_centered(coords, charges):
    """
    Compute molecular dipole relative to center of geometry.
    coords  : (N, 3) positions in Å
    charges : (N,) charges in e
    Returns dipole vector in Debye
    """
    center = np.mean(coords, axis=0)
    coords_rel = coords - center
    dip_eA = np.sum(charges[:, None] * coords_rel, axis=0)
    return dip_eA * 4.80320427

def angle_with_z(vector):
    """Compute angle (degrees) between vector and z-axis."""
    z_axis = np.array([0, 0, 1])
    cos_theta = np.dot(vector, z_axis) / (np.linalg.norm(vector) + 1e-12)
    cos_theta = np.clip(cos_theta, -1, 1)
    return np.degrees(np.arccos(cos_theta))


# Get all numeric folders and sort them by numeric value
folders = [f for f in os.listdir(".") if os.path.isdir(f) and f.isdigit()]
folders = sorted(folders, key=lambda x: int(x))

folder_index = 1

for folder in folders:
    xyz_files = [f for f in os.listdir(folder) if f.endswith(".xyz")]
    if not xyz_files:
        continue

    xyz_path = os.path.join(folder, xyz_files[0])

    atoms = read_xyz(xyz_path)
    if len(atoms) <= 98:
        print(f"⚠️ Skipping {folder}: not enough atoms (need at least 99).")
        continue

    # Water atoms
    O_idx, H1_idx, H2_idx = 96, 97, 98
    O_pos = atoms[O_idx][1]
    H1_pos = atoms[H1_idx][1]
    H2_pos = atoms[H2_idx][1]
    water_positions = np.array([O_pos, H1_pos, H2_pos])

    # Center of geometry
    center_geom = np.mean(water_positions, axis=0)

    # === Distances from water center of geometry to carbon atoms ===
    carbon_positions = [pos for sym, pos in atoms if sym == "C"]

    if carbon_positions:
        dists_to_carbons = [
            np.linalg.norm(center_geom - c_pos)
            for c_pos in carbon_positions
        ]

        min_C_dist = np.min(dists_to_carbons)
        max_C_dist = np.max(dists_to_carbons)
        std_C_dist = np.std(dists_to_carbons)
    else:
        min_C_dist = np.nan
        max_C_dist = np.nan
        std_C_dist = np.nan

    # Minimum O···H distance
    OH_dists = [
        np.linalg.norm(O_pos - pos)
        for i, (sym, pos) in enumerate(atoms)
        if sym == "H" and i not in [H1_idx, H2_idx]
        and np.linalg.norm(O_pos - pos) <= cutoff
    ]
    min_OH = np.min(OH_dists) if OH_dists else np.nan

    # Minimum N···H distance
    NH_dists = []
    for sym, pos in atoms:
        if sym == "N":
            for H_pos in [H1_pos, H2_pos]:
                d = np.linalg.norm(H_pos - pos)
                if d <= cutoff:
                    NH_dists.append(d)
    min_NH = np.min(NH_dists) if NH_dists else np.nan

    # Dipole
    water_charges = np.array([-2, 1, 1])
    dipole_vec = compute_dipole_centered(water_positions, water_charges)
    dipole_mag = np.linalg.norm(dipole_vec)
    dipole_angle = angle_with_z(dipole_vec)

    results.append({
        "Index": folder_index,
        "Folder": int(folder),
        "Water_COG_x": center_geom[0],
        "Water_COG_y": center_geom[1],
        "Water_COG_z": center_geom[2],
        "Min_OH_distance": min_OH,
        "Min_NH_distance": min_NH,
        "Dist_to_C_min": min_C_dist,
        "Dist_to_C_max": max_C_dist,
        "Dist_to_C_std": std_C_dist,
        "Dipole_X(D)": dipole_vec[0],
        "Dipole_Y(D)": dipole_vec[1],
        "Dipole_Z(D)": dipole_vec[2],
        "Dipole_angle_deg": dipole_angle,
        "Dipole_Magnitude(D)": dipole_mag
    })

    folder_index += 1

df = pd.DataFrame(results)

cols = ["Index"] + [c for c in df.columns if c != "Index"]
df = df[cols]

df.to_excel("manual features.xlsx", index=False)
print("✅ Results saved to 'manual features.xlsx'")
