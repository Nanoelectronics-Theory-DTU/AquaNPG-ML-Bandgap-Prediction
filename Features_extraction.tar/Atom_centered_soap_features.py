import os
import sys
import numpy as np
from ase import Atoms
from ase.io import read
from dscribe.descriptors import SOAP
from tqdm import tqdm
import pandas as pd

# -----------------------------
# Usage: python script.py parent_directory
# -----------------------------
if len(sys.argv) < 2:
    print("Usage: python script.py <parent_directory>")
    sys.exit(1)

parent_dir = sys.argv[1]
if not os.path.isdir(parent_dir):
    print(f"Error: Directory '{parent_dir}' does not exist.")
    sys.exit(1)

# -----------------------------
# USER: Define lattice vectors here (Å)
# Format: 3x3 array, each row is a lattice vector
# -----------------------------
lattice = np.array([[32.786, 0.0, 0.0],
                    [0.0, 8.69346, 0.0],
                    [0.0, 0.0, 12.0]])

# Species list for SOAP
species = ["H", "C", "O", "N"]

soap = SOAP(
    species=species,
    r_cut=6.0,
    n_max=8,
    l_max=6,
    periodic=True  # periodic SOAP
)

# -----------------------------
# Storage lists
# -----------------------------
features = []
frame_ids = []
folder_names = []

# Loop over numeric directories
numeric_dirs = [f for f in os.listdir(parent_dir) if f.isdigit() and os.path.isdir(os.path.join(parent_dir, f))]
numeric_dirs.sort()

for folder in numeric_dirs:
    folder_path = os.path.join(parent_dir, folder)
    xyz_files = sorted([f for f in os.listdir(folder_path) if f.endswith('.xyz')])

    for xyz_file in tqdm(xyz_files, desc=f"Processing folder {folder}"):
        file_path = os.path.join(folder_path, xyz_file)
        try:
            # Read XYZ positions only
            atoms = read(file_path)

            # Add lattice vectors and set PBC
            atoms.set_cell(lattice)
            atoms.set_pbc([True, True, True])

            # Select graphene atoms (C and N)
            graphene_indices = [i for i, atom in enumerate(atoms) if atom.symbol.upper() in ["C", "N"]]

            if graphene_indices:
                soap_vectors = soap.create(atoms, centers=graphene_indices)
                full_sys_vector = np.mean(soap_vectors, axis=0)
            else:
                feature_length = soap.get_number_of_features()
                full_sys_vector = np.full(feature_length, np.nan)

            features.append(full_sys_vector)
            frame_ids.append(xyz_file)
            folder_names.append(folder)

        except Exception as e:
            print(f"Failed on {folder}/{xyz_file}: {e}")
            feature_length = soap.get_number_of_features()
            features.append(np.full(feature_length, np.nan))
            frame_ids.append(xyz_file)
            folder_names.append(folder)

# Convert to DataFrame
features = np.array(features)
df = pd.DataFrame(features)
df.insert(0, "folder", folder_names)
df.insert(1, "frame", frame_ids)

# Save to Excel
output_file = "soap_features_graphene_all_folders.xlsx"
df.to_excel(output_file, index=False)
print(f"✅ Saved graphene-centered SOAP features for all folders to {output_file}")

