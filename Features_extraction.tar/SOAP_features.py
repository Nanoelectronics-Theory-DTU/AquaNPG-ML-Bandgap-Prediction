import os
import sys
import numpy as np
from ase.io import read
from dscribe.descriptors import SOAP
from tqdm import tqdm
import pandas as pd

# -----------------------------
# Usage: python script.py xyz_frames
# -----------------------------

if len(sys.argv) < 2:
    print("Usage: python script.py <xyz_frames_directory>")
    sys.exit(1)

xyz_dir = sys.argv[1]

if not os.path.isdir(xyz_dir):
    print(f"Error: Directory '{xyz_dir}' does not exist.")
    sys.exit(1)

# Adapt species list to your system
species = ["H", "C", "O", "N"]  # example, add your elements

soap = SOAP(
    species=species,
    r_cut=6.0,
    n_max=8,
    l_max=6,
    periodic=True  # change to True if your system is periodic
)

features = []
frame_ids = []

xyz_files = sorted([f for f in os.listdir(xyz_dir) if f.endswith('.xyz')])

for xyz_file in tqdm(xyz_files, desc="Processing XYZ files"):
    try:
        atoms = read(os.path.join(xyz_dir, xyz_file))
        soap_vectors = soap.create(atoms)  # (num_atoms, feature_length)
        full_sys_vector = np.mean(soap_vectors, axis=0)  # average over atoms
        features.append(full_sys_vector)
        frame_ids.append(xyz_file)
    except Exception as e:
        print(f"Failed on {xyz_file}: {e}")

# Convert to DataFrame
features = np.array(features)
df = pd.DataFrame(features)
df.insert(0, "frame", frame_ids)

# Save to Excel
output_file = "soap_features.xlsx"
df.to_excel(output_file, index=False)
print(f"Saved full system SOAP features to {output_file}")

