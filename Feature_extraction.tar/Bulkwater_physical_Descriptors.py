import os
import numpy as np
import pandas as pd

results = []

# =========================
# USER SETTINGS
# =========================

boundary_atom_1 = 55   # 0-based atom index
boundary_atom_2 = 58   # 0-based atom index

surface_normal = np.array([0.0, 0.0, 1.0])

OH_contact_cutoff = 2.5
NH_contact_cutoff = 2.5

output_file = "final_selected_features_with_ribbon_dipoles.xlsx"


def read_xyz(file_path):
    with open(file_path) as f:
        lines = f.readlines()

    atoms = []
    for line in lines[2:]:
        parts = line.split()
        if len(parts) >= 4:
            atoms.append((parts[0], np.array(list(map(float, parts[1:4])))))
    return atoms


def compute_dipole_centered(coords, charges):
    center = np.mean(coords, axis=0)
    coords_rel = coords - center
    dip_eA = np.sum(charges[:, None] * coords_rel, axis=0)
    return dip_eA * 4.80320427   # Debye


def angle_with_normal(vec, normal):
    vnorm = np.linalg.norm(vec)
    nnorm = np.linalg.norm(normal)

    if vnorm == 0 or nnorm == 0:
        return np.nan

    cosang = np.dot(vec, normal) / (vnorm * nnorm)
    cosang = np.clip(cosang, -1.0, 1.0)

    return np.degrees(np.arccos(cosang))


def detect_waters(atoms):
    """
    Assumes each water appears as O H H consecutively in xyz.
    """
    waters = []
    water_charges = np.array([-2, 1, 1])

    for i in range(len(atoms) - 2):
        if atoms[i][0] == "O" and atoms[i+1][0] == "H" and atoms[i+2][0] == "H":
            coords = np.array([
                atoms[i][1],
                atoms[i+1][1],
                atoms[i+2][1]
            ])

            cog = np.mean(coords, axis=0)
            dip_vec = compute_dipole_centered(coords, water_charges)
            dip_mag = np.linalg.norm(dip_vec)
            dip_angle = angle_with_normal(dip_vec, surface_normal)

            waters.append({
                "O_index": i,
                "H_indices": [i + 1, i + 2],
                "O_coord": atoms[i][1],
                "H_coords": [atoms[i+1][1], atoms[i+2][1]],
                "COG": cog,
                "dip_vec": dip_vec,
                "dip_mag": dip_mag,
                "dip_angle": dip_angle
            })

    return waters


def water_water_OH_features(waters):
    distances = []

    for i, wi in enumerate(waters):
        O_coord = wi["O_coord"]

        for j, wj in enumerate(waters):
            if i == j:
                continue

            for H_coord in wj["H_coords"]:
                distances.append(np.linalg.norm(O_coord - H_coord))

    if len(distances) == 0:
        return np.nan, np.nan, 0

    distances = np.array(distances)

    return (
        np.min(distances),
        np.mean(distances),
        np.sum(distances <= OH_contact_cutoff)
    )


def substrate_NH_features(atoms, waters):
    N_coords = np.array([pos for sym, pos in atoms if sym == "N"])

    if len(N_coords) == 0:
        return np.nan, np.nan, 0

    H_coords = []
    for w in waters:
        H_coords.extend(w["H_coords"])

    H_coords = np.array(H_coords)

    distances = []

    for N in N_coords:
        for H in H_coords:
            distances.append(np.linalg.norm(N - H))

    if len(distances) == 0:
        return np.nan, np.nan, 0

    distances = np.array(distances)

    return (
        np.min(distances),
        np.mean(distances),
        np.sum(distances <= NH_contact_cutoff)
    )


def total_layer_features(waters, atoms):
    """
    Original selected features for the full water layer.
    """
    if len(waters) == 0:
        return {}

    cogs = np.array([w["COG"] for w in waters])
    dipoles = np.array([w["dip_vec"] for w in waters])
    dip_mags = np.array([w["dip_mag"] for w in waters])
    dip_angles = np.array([w["dip_angle"] for w in waters])

    total_dip = np.sum(dipoles, axis=0)

    min_OH, mean_OH, num_OH = water_water_OH_features(waters)
    min_NH, mean_NH, num_NH = substrate_NH_features(atoms, waters)

    return {
        "Water_COG_mean_x": np.mean(cogs[:, 0]),
        "Water_COG_mean_y": np.mean(cogs[:, 1]),
        "Water_COG_mean_z": np.mean(cogs[:, 2]),

        "Water_COG_std_x": np.std(cogs[:, 0]),
        "Water_COG_std_y": np.std(cogs[:, 1]),
        "Water_COG_std_z": np.std(cogs[:, 2]),

        "Total_Dipole_X": total_dip[0],
        "Total_Dipole_Y": total_dip[1],
        "Total_Dipole_Z": total_dip[2],
        "Total_Dipole_Mag": np.linalg.norm(total_dip),

        "Mean_Water_Dipole": np.mean(dip_mags),
        "Std_Water_Dipole": np.std(dip_mags),

        "Mean_Water_Dipole_Angle": np.nanmean(dip_angles),
        "Std_Water_Dipole_Angle": np.nanstd(dip_angles),

        "Min_OH_distance": min_OH,
        "Mean_OH_distance": mean_OH,
        "Num_OH_contacts": num_OH,

        "Min_NH_distance": min_NH,
        "Mean_NH_distance": mean_NH,
        "Num_NH_contacts": num_NH,
    }


def ribbon_dipole_features(waters):
    """
    Ribbon-wise features: only dipole-related quantities.
    No angle features are used ribbon-wise.
    """
    if len(waters) == 0:
        return {
            "Total_Dipole_X": np.nan,
            "Total_Dipole_Y": np.nan,
            "Total_Dipole_Z": np.nan,
            "Total_Dipole_Mag": np.nan,
            "Mean_Water_Dipole": np.nan,
            "Std_Water_Dipole": np.nan,
        }

    dipoles = np.array([w["dip_vec"] for w in waters])
    dip_mags = np.array([w["dip_mag"] for w in waters])

    total_dip = np.sum(dipoles, axis=0)

    return {
        "Total_Dipole_X": total_dip[0],
        "Total_Dipole_Y": total_dip[1],
        "Total_Dipole_Z": total_dip[2],
        "Total_Dipole_Mag": np.linalg.norm(total_dip),

        "Mean_Water_Dipole": np.mean(dip_mags),
        "Std_Water_Dipole": np.std(dip_mags),
    }


def dipole_difference(central_feats, peripheral_feats):
    """
    Difference = Central_Ribbon - Peripheral_Ribbon
    """
    diff = {}

    for key in central_feats:
        diff[key] = central_feats[key] - peripheral_feats[key]

    return diff


# =========================
# MAIN LOOP
# =========================

folders = [f for f in os.listdir(".") if os.path.isdir(f) and f.isdigit()]
folders = sorted(folders, key=lambda x: int(x))

folder_index = 1

for folder in folders:
    xyz_files = [f for f in os.listdir(folder) if f.endswith(".xyz")]

    if not xyz_files:
        continue

    xyz_path = os.path.join(folder, xyz_files[0])
    atoms = read_xyz(xyz_path)

    waters = detect_waters(atoms)

    if len(waters) == 0:
        print(f"⚠️ Skipping {folder}: no waters detected.")
        continue

    if boundary_atom_1 >= len(atoms) or boundary_atom_2 >= len(atoms):
        print(f"⚠️ Skipping {folder}: boundary atom index out of range.")
        continue

    x_b1 = atoms[boundary_atom_1][1][0]
    x_b2 = atoms[boundary_atom_2][1][0]

    x_left, x_right = sorted([x_b1, x_b2])

    central_ribbon = []
    peripheral_ribbon = []

    for w in waters:
        x = w["COG"][0]

        if x_left <= x <= x_right:
            central_ribbon.append(w)
        else:
            peripheral_ribbon.append(w)

    total_feats = total_layer_features(waters, atoms)

    central_dipole_feats = ribbon_dipole_features(central_ribbon)
    peripheral_dipole_feats = ribbon_dipole_features(peripheral_ribbon)

    diff_dipole_feats = dipole_difference(
        central_dipole_feats,
        peripheral_dipole_feats
    )

    row = {
        "Index": folder_index,
        "Folder": int(folder),
    }

    for key, val in total_feats.items():
        row[key] = val

    for key, val in central_dipole_feats.items():
        row[f"Central_Ribbon_{key}"] = val

    for key, val in peripheral_dipole_feats.items():
        row[f"Peripheral_Ribbon_{key}"] = val

    for key, val in diff_dipole_feats.items():
        row[f"Ribbon_Difference_{key}"] = val

    results.append(row)
    folder_index += 1


df = pd.DataFrame(results)
df.to_excel(output_file, index=False)

print(f"✅ Results saved to '{output_file}'")
